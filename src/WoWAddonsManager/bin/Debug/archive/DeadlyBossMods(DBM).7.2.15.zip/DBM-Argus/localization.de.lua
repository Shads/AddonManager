if GetLocale() ~= "deDE" then return end
local L

---------------------------
-- Goroth --
---------------------------
L= DBM:GetModLocalization(1862)

-----------------------
-- Mistress Alluradel --
-----------------------
L= DBM:GetModLocalization(2011)

-----------------------
-- Ovetigo --
-----------------------
L= DBM:GetModLocalization(2013)

-----------------------
-- Sotanathor --
-----------------------
L= DBM:GetModLocalization(2014)

-----------------------
-- Matron Folnuna --
-----------------------
L= DBM:GetModLocalization(2010)

-----------------------
-- Keeper Aedis --
-----------------------
L= DBM:GetModLocalization(2002)

-----------------------
-- Void-Blade Zedaat --
-----------------------
L= DBM:GetModLocalization(2003)

-----------------------
-- Pit Lord Vilemus --
-----------------------
L= DBM:GetModLocalization(2015)
